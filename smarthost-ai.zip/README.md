# SmartHost AI

Prototype d'assistant IA vocal pour hôtels et locations saisonnières.
Ce projet est hébergé sur GitHub Pages et simule une interface d'accueil vocale multilingue.
